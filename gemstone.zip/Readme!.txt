By installing or using this font, you are agree to the Product Usage Agreement:

1. This font for PERSONAL USE. No commercial use allowed!
2. If you want to use this font for commercial use you must buy a commercial license.
3. LINK TO PURCHASE COMMERSIAL LICENSE:

https://blankidsfonts.com/product/gemstone/

to DONATE click here:
Paypal.me/blankids

if you need more detailed information you can contact me at:
blankids.co@gmail.com


Thanks,
Blankids Studio